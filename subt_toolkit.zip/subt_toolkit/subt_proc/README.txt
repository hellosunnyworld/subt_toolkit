Execution method:
1. Open scripts/filter.py, revise inf and outf (package names)
2. Check the topic names of odometer and imu in src/subt_proc_node.cpp
3. Revise the input bag name in launch/subt_proc.launch
4. run launch file
